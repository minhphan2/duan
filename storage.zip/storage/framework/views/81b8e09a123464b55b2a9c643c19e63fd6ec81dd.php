<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>VTQ Bakery</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/header.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/root.css')); ?>">
    
    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>
    
    <?php echo $__env->make('viewphu.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    
    <div class="main">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

</body>
</html>
<?php /**PATH D:\duan\resources\views\layout\app.blade.php ENDPATH**/ ?>