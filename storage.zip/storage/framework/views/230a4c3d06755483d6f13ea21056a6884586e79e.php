<body>
<form action="<?php echo e(route('password.email')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <h2>Quên mật khẩu</h2>

    <input type="email" name="email" placeholder="Email" required>
    
    <?php if($errors->any()): ?>
        <div style="color:red"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <button type="submit">Gửi mã</button>
</form>
</body><?php /**PATH D:\duan\resources\views\quenmatkhau.blade.php ENDPATH**/ ?>