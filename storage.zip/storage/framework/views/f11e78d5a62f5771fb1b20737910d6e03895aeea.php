<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-container" id="product-container">
                        <a href="<?php echo e(route('chitietsanpham', ['id' => $product->MaSP])); ?>">
                            <p class="product-name"><?php echo e($product->TenSP); ?></p>
                            <p class="price"><?php echo e($product->MoTa); ?><br><?php echo e(number_format($product->Gia, 0, ',', '.')); ?> ₫</p>
                            <img src="<?php echo e(asset('uploads/' . $product->HinhAnh)); ?>" alt="<?php echo e($product->name); ?>">
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\duan\resources\views\sanpham\ajax_banhsinhnhat.blade.php ENDPATH**/ ?>