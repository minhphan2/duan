<form action="<?php echo e(route('password.update')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <h2>Nhập mã và mật khẩu mới</h2>

    <input type="email" name="email" placeholder="Email" required>
    <input type="text" name="token" placeholder="Mã xác nhận" required>
    <input type="password" name="password" placeholder="Mật khẩu mới" required>
    <input type="password" name="password_confirmation" placeholder="Xác nhận mật khẩu mới" required>

    <?php if($errors->any()): ?>
        <div style="color:red"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <button type="submit">Đặt lại mật khẩu</button>
</form>
<?php /**PATH D:\duan\resources\views\laylaimk.blade.php ENDPATH**/ ?>