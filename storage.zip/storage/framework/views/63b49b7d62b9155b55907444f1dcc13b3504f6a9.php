<!DOCTYPE html>
<html>
<head>
    <title>Thông báo trạng thái đơn hàng</title>
</head>
<body>
    <h2>Xin chào <?php echo e($tenKhach); ?>!</h2>

    <?php if($trangThai === 'Đang giao'): ?>
        <p>Đơn hàng của bạn hiện đang được giao. Vui lòng giữ điện thoại để nhận hàng!</p>
    <?php elseif($trangThai === 'Hoàn tất'): ?>
        <p>Chúc mừng bạn đã nhận hàng thành công. Cảm ơn bạn đã mua sắm tại cửa hàng chúng tôi!</p>
    <?php else: ?>
        <p>Trạng thái đơn hàng: <?php echo e($trangThai); ?></p>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\duan\resources\views\emails\trang_thai_don_hang.blade.php ENDPATH**/ ?>